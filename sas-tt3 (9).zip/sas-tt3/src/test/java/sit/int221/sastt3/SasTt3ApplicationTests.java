package sit.int221.sastt3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SasTt3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
